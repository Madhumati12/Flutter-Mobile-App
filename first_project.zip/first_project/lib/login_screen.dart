import 'package:flutter/material.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _inputController = TextEditingController();
  bool isPhoneSelected = true; // Initially, Phone is selected

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Toggle for Phone or Email
            Center(
              child: ToggleButtons(
                borderRadius: BorderRadius.circular(50),
                borderColor: Colors.grey,
                fillColor: Colors.red[100],
                selectedColor: Colors.red,
                selectedBorderColor: Colors.red,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.0),
                    child: Text('Phone'),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.0),
                    child: Text('Email'),
                  ),
                ],
                isSelected: [isPhoneSelected, !isPhoneSelected],
                onPressed: (index) {
                  setState(() {
                    isPhoneSelected = index == 0;  // Update the toggle state
                    _inputController.clear();       // Clear the input field when toggling
                  });
                },
              ),
            ),
            SizedBox(height: 10),

            // Added "Glad to see you!" text
            Center(
              child: Text(
                'Glad to see you!',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 20),

            // Input field for either Phone or Email
            TextField(
              controller: _inputController,
              keyboardType:
                  isPhoneSelected ? TextInputType.phone : TextInputType.emailAddress,
              decoration: InputDecoration(
                labelText: isPhoneSelected ? 'Mobile Number' : 'Email Address',
                hintText: isPhoneSelected ? 'Enter your phone number' : 'Enter your email',
              ),
            ),
            SizedBox(height: 20),

            // Button to send OTP
            ElevatedButton(
              onPressed: () {
                String input = _inputController.text;

                // Ensure the user has entered something
                if (input.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Please enter your ${isPhoneSelected ? 'phone number' : 'email'}')),
                  );
                  return;
                }

                // Navigate to the OTP screen with the input
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => OtpScreen(mobileNumber: input),
                  ),
                );
              },
              child: Text('Get OTP'),
            ),
          ],
        ),
      ),
    );
  }
}
